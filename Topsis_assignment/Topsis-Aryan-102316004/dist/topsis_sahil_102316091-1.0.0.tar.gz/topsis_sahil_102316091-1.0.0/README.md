# Topsis-Sahil-102316091

A Python package to implement TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution).

## Installation

```bash
pip install Topsis-Sahil-102316091
```

## Usage

### Command Line

```bash
topsis <InputDataFile> <Weights> <Impacts> <OutputResultFileName>
```

Example:

```bash
topsis data.csv "1,1,1,1,1" "+,+,+,+,+" result.csv
```

### Python Script

```python
from topsis.main import topsis_logic
import pandas as pd

# Load your dataframe
df = pd.read_csv("data.csv")

# processing...
# ...
```

## License

MIT
